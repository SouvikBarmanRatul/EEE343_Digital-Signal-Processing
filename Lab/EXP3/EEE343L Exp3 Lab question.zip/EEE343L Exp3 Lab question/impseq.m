function [n,x]=impseq(n_start, n_end, n0)
n= n_start : n_end;
x= zeros(1,length(n));
x(n==n0) =1;
end