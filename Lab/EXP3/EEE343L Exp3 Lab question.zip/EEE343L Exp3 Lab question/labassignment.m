%% Question (i(a))
close all; 
clear all; 
clc; 
[n, d1] = impseq(-5, 5, -2); 
[~, d2] = impseq(-5, 5, 4); 
x = 2*d1 - d2; 
figure('Color', 'w'); 
prettystem(n, x, 'x(n) = 2\delta(n+2) - \delta(n-4)', [0.47 0.67 0.19]);

%% Question (i(b))
close all; 
clear all; 
clc; 
[n, u1] = unitseq(0, 20, 0); 
[~, u2] = unitseq(0, 20, 12); 
[~, u3] = unitseq(0, 20, 9);
[~, u4] = unitseq(0, 20, 20); 

x = n.*(u1 - u2) + 10*exp(-0.5*(n-10)).*(u3 - u4); 

figure('Color', 'w'); 
prettystem(n, x, 'x(n) = n[u(n)-u(n-12)] + 10e^{-0.5(n-10)}[u(n-9)-u(n-20)]', [0.47 0.67 0.19]); 

%% Question (ii(a))
close all;
clear all; 
clc;

x = [1 2 3 4 5 6 7 6 5 4 3 2 1]; 
n = -5:7; 

[n1, x1_part] = sigshift(n, 3*x, 5);  
[n2, x2_part] = sigshift(n, -4*x, -4); 


[n_shift, x1] = sigadd(n1, x1_part, n2, x2_part); 

figure('Color', 'w');
prettystem(n_shift, x1, 'x_1(n) = 3x(n-5) - 4x(n+4)', [0.47 0.67 0.19]); 

%% Question (ii(b))
close all; 
clear all; 
clc; 

x = [1 2 3 4 5 6 7 6 5 4 3 2 1]; 
n = -5:7;

[m_fold, x_fold] = sigfold(n, x); % x(2-n) -> Fold x(n) and shift by +2
[n_term1, x_term1] = sigshift(m_fold, x_fold, 2); 

%  x(n) * x(n-4)
[n_shift4, x_shift4] = sigshift(n, x, 4); 
[n_term2, x_term2] = sigmult(n, x, n_shift4, x_shift4);


[n_out, x2] = sigadd(n_term1, x_term1, n_term2, x_term2); 

figure('Color', 'w'); 
prettystem(n_out, x2, 'x_2(n) = x(2-n) + x(n)x(n-4)', [0.47 0.67 0.19]); 