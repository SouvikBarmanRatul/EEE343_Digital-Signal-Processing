close all;
clear all;
clc;
n = 0:10; 
x = 3*cos(0.1*pi*n + pi/3) + 2*sin(0.5*pi*n); 

figure('Color', 'w'); 
prettystem(n, x, 'Discrete Signal x(n)', [0.47 0.67 0.19]); 