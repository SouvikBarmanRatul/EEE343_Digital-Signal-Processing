function prettystem(n, x, ttl, col)
% Nicely styled stem plot (helper used by lab3_main.m)
if nargin < 4, col = [0.00 0.45 0.74]; end
stem(n, x, 'filled', 'LineWidth', 1.8, 'MarkerSize', 7, ...
'Color', col, 'MarkerFaceColor', col, 'MarkerEdgeColor', 'w');
grid on; box off;
set(gca, 'FontSize', 11, 'LineWidth', 1, 'GridAlpha', 0.25);
xlim([min(n)-1, max(n)+1]);
r = max(max(x)-min(x), 1);
ylim([min(x)-0.15*r, max(x)+0.15*r]);
line(xlim, [0 0], 'Color', [0.3 0.3 0.3], 'LineWidth', 0.8); % x-axis
line([0 0], ylim, 'Color', [0.5 0.5 0.5], 'LineStyle', '--'); % n = 0 marker
title(ttl, 'FontWeight', 'bold');
xlabel('index n'); ylabel('x(n)');
end