function [n,y] = sigadd(n1, x1, n2, x2)

    n = min(min(n1),min(n2)) : max(max(n1),max(n2));
    x1e = zeros(1,length(n));
    x2e = zeros(1,length(n));
    x1e(n>=min(n1) & n<=max(n1)) = x1;
    x2e(n>=min(n2) & n<=max(n2)) = x2;
    y = x1e + x2e;

end
