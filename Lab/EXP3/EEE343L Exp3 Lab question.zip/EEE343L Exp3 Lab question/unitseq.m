function [n,x]=unitseq(n_start, n_end, n0)

n= n_start : n_end;
x= double(n>=n0);

end