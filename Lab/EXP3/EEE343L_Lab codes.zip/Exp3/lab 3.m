close all;
clear all;
clc;
%% unit impulse sequence
n0=-1;
[n,x]=impseq(-2,5,n0)
figure('color','w');
prettystem(n,x, sprintfy(' Unit Impulse //delta(n-%d)',n0));