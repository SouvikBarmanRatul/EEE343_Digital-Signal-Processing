close all;
clear all;
clc;
%% unit impulse sequence
n0=-1;
[n,x]=impseq(-2,5,n0)
figure('color','w');
prettystem(n,x, sprintf('Unit Impulse \\delta(n-%d)',n0));

%% unit Step sequence

[n,x]=unitseq(-5,6,-2);
figure('color','w');
prettystem(n,x, 'Unit Step u(n)', [0.85 0.33 0.10]);

%% Ramp Signal

n= -5:5;
x =(n>=2).*n;
figure('color','w');
prettystem(n,x, 'Ramp r(n)', [0.47 0.67 0.19]);
%% Problem 2 
n=0:10;
x=exp ((2+3j)*n);
figure('Color','w');
subplot(3,1,1);prettystem(n,real(x),'Real part(linear scale)');
ylabel('Re\{x(n)\}');
subplot(3,1,2);prettystem(n,imag(x),'Imaginary part(linear scale)',[0.0 0.85 0.33]);
ylabel('Im \{x(n)\}');
subplot (3,1,3);prettystem(n,abs(x),'Magnitude (linear scale)', [0.47 0.67 0.19]);
ylabel('|x(n)|');



%% Problem 3: Addition of two signals
x1 = [2 5 4 -3 4 2];  n1 = -3:2;
x2 = [1 2 4 -5 3];    n2 = 0:4;

% Add the two signals with non-matching time indices
[n, y] = sigadd(n1, x1, n2, x2);
xl = [min(n)-1, max(n)+1];              % Same x-range for all three plots

% Plotting the original and summed signals
figure('Color','w');
subplot(3,1,1); prettystem(n1, x1, 'x_1(n)');                           xlim(xl);
subplot(3,1,2); prettystem(n2, x2, 'x_2(n)', [0.85 0.33 0.10]);         xlim(xl);
subplot(3,1,3); prettystem(n, y, 'x_1(n) + x_2(n)', [0.47 0.67 0.19]);   xlim(xl);


%% Signal Scaling 

n = -3:3;
x = [1 2 -1 3 2 -2 1];
a = -1;
y = a*x;

figure('Color','w');
subplot(2,1,1);
prettystem(n,x,'Original Signal x(n)');

subplot(2,1,2);
prettystem(n,y,'Scaled Signal 2x(n)',[0.49 0.18 0.56]);


%% Problem 4: Shifting
n = -1:2;
x = [-2 3 5 4];
k = -2;
[m, y] = sigshift(n, x, k);

figure('Color','w');
subplot(2,1,1);
stem(n, x)
subplot(2,1,2);
prettystem(m, y)

%% Problem 5: Folding
n = -2:3;
x = [4 -2 3 5 4 6];
[m, y] = sigfold(n, x);
figure('Color','w');
subplot(2,1,1);
stem(n, x)
subplot(2,1,2);
stem(m, y)




