function [m,y] = sigshift(n,x,k)

m=n+k;
y= x;

end
